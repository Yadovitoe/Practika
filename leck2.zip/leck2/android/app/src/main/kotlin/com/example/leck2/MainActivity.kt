package com.example.leck2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
