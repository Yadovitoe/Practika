import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Счётчик',
      home: CounterScreen(),
    );
  }
}

class CounterScreen extends StatefulWidget {
  @override
  CounterScreenState createState() => CounterScreenState();
}

class CounterScreenState extends State<CounterScreen> {
  int counter = 0;

  void incrementCounter() {
    setState(() {
      counter++;
    });
  }

  void resetCounter() {
    setState(() {
      counter = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Счётчик'),
        leading: IconButton(
          icon: Icon(Icons.refresh),
          onPressed: resetCounter,
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CounterDisplay(counter: counter),
            ColorChangingText(counter: counter), // Новый StatefulWidget
            ElevatedButton(
              onPressed: incrementCounter,
              child: Text('Pressed $counter times'),
            ),
          ],
        ),
      ),
    );
  }
}

class CounterDisplay extends StatelessWidget {  //StatelessWidget
  final int counter;

  CounterDisplay({required this.counter});

  @override
  Widget build(BuildContext context) {
    return Text(
      'Current count: $counter',
      style: TextStyle(fontSize: 24),
    );
  }
}

class ColorChangingText extends StatefulWidget {  //StatefulWidget
  final int counter;

  ColorChangingText({required this.counter});

  @override
  ColorChangingTextState createState() => ColorChangingTextState();
}

class ColorChangingTextState extends State<ColorChangingText> {
  late Color textColor;

  @override
  void initState() {
    super.initState();
    textColor = Colors.black;
  }

  @override
  void didUpdateWidget(ColorChangingText oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.counter % 2 == 0) {
      textColor = Colors.blue;
    } else {
      textColor = Colors.red;
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Text(
      'Count is ${widget.counter}',
      style: TextStyle(fontSize: 24, color: textColor),
    );
  }
}
